close all
clear all
clc

global L H alpha gamma eps V

L = 8;                  % profondit� del campo
H = 8;                  % altezza del campo
gamma = 1;
alpha = 0.0;
eps = 0.0;
V = 1:0.5:H-1;

% inizializzazione casuale
rng(4)
Q = load('Q.mat');
Qup = Q.Qup; Qdown = Q.Qdown; Qstill = Q.Qstill;

chk = -1;
xRnd = rand; yRnd = rand; bRnd = rand;
xb0 = L*xRnd;
yb0 = H*yRnd;
yp0 = (H-1)*bRnd+1;

[chk,Qup,Qdown,Qstill,score,rimbalzi] = PongEffect(xb0,yb0,yp0,Qup,Qdown,Qstill);

%%% Calcolo della funzione Valore %%%
Vpi = zeros(L+1,H+1,length(V),2,2);
for i = 1:L+1
   for j = 1:H+1 
      for k = 1:length(V)
        Vpi(i,j,k,1,1) = max([Qup(i,j,k,1,1),Qdown(i,j,k,1,1),Qstill(i,j,k,1,1)]);
      end
   end
end


